package com.hyred.hyred;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HyredApplicationTests {

	@Test
	void contextLoads() {
	}

}
